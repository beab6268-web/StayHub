import { AuthForm } from '../components/AuthForm';

export const Register = () => {
  return <AuthForm mode="register" />;
};
